const cmd = '排行榜';
const len = 5;

function getText(e) {
    var rt = '';
    for (i in e.message) {
        switch (e.message[i].type) {
            case "text":
                rt += e.message[i].text;
                break;
        }
    }
    return rt;
}


function onStart(api){
    api.listen('onMainMessageReceived',(e)=>{
        let t = getText(e);
        if(t==cmd){
            let tmp_data = NIL._vanilla.get_all();
			let p_arr = data_sort(tmp_data);
			let arr_data = [];
			arr_data[0] = `在线排行榜\n\n`;
			for(let n = 0; n < p_arr.length && n < len; n++){
				let d = n + 1;
				arr_data[d] = `${timeFormat(p_arr[n].period)}h\t\t\t${p_arr[n].xboxid}\n`;
			}
			e.reply(arr_data);
        }
    });
}

function data_sort(tmp_data){
	let p_data = JSON.parse(JSON.stringify(tmp_data, null, '\t'));
	let p_arr = [];
	var i = 0;
	for(let m in p_data){
		let tmp = p_data[m];
		p_arr[i] = {xboxid:tmp.xboxid,period:tmp.period};
		i++;
	}	
	p_arr.sort(compare('period'));
	p_arr.reverse();
	return p_arr;
}

function compare(prop){
	return function(a,b) {
		var value1 = a[prop];
		var value2 = b[prop];
		return value1-value2
	}
}


function timeFormat(dur){
    if (dur!==0){
        let hour=3600*1000;
        return (dur/hour).toFixed(2);
    }
    return 0;
}


module.exports = {
    onStart,
    onStop(){}
}
